# LRSSL
The R scirpt of Laplacian regularized sparse subspace learning(LRSSL) for drug indication prediction with test data.
