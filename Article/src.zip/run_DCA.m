
maxiter = 20;
restartProb = 0.50;
dim_drug = 100;
dim_prot = 400;

drugNets = {'Sim_drug_pubchem_mat', 'Sim_drug_target_domain_mat', 'Sim_drug_target_go_mat', 'Sim_drug_dis_mat'};
% proteinNets = {'disease_similarity'};

tic
X = DCA(drugNets, dim_drug, restartProb, maxiter);
toc
% tic
% Y = DCA(proteinNets, dim_prot, restartProb, maxiter);
% toc

dlmwrite(['../feature/drug_vector_4fullll_restart5_d', num2str(dim_drug), '.txt'], X, '\t');
% dlmwrite(['../feature/protein_vector_d', num2str(dim_prot), '.txt'], Y, '\t');
